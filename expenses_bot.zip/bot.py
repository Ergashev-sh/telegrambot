
import json
from datetime import datetime
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

# Ma'lumotlar fayli
DATA_FILE = "database.json"

# Ma'lumotlarni o'qish
def load_data():
    try:
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {"income": [], "expense": []}

# Ma'lumotlarni saqlash
def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

# /start buyrug'i
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Salom! Men sizning kirim va chiqimlaringizni boshqaruvchi botman. Kirim yoki chiqim qo'shish uchun:\n"
        "+ [miqdor] [kategoriya] - Kirim qo'shish\n"
        "- [miqdor] [kategoriya] - Chiqim qo'shish\n"
        "Balansni bilish uchun: /balans"
    )

# Kirim yoki chiqim qo'shish
async def add_transaction(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    data = load_data()

    if text.startswith("+"):
        _, amount, category = text.split(maxsplit=2)
        data["income"].append({"amount": int(amount), "category": category, "date": str(datetime.now().date())})
        save_data(data)
        await update.message.reply_text(f"Kirim qo'shildi: {amount} so'm - {category}")

    elif text.startswith("-"):
        _, amount, category = text.split(maxsplit=2)
        data["expense"].append({"amount": int(amount), "category": category, "date": str(datetime.now().date())})
        save_data(data)
        await update.message.reply_text(f"Chiqim qo'shildi: {amount} so'm - {category}")

# Balansni ko'rsatish
async def balans(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    income_total = sum(item["amount"] for item in data["income"])
    expense_total = sum(item["amount"] for item in data["expense"])
    balance = income_total - expense_total
    await update.message.reply_text(
        f"Umumiy kirim: {income_total} so'm\n"
        f"Umumiy chiqim: {expense_total} so'm\n"
        f"Balans: {balance} so'm"
    )

# Asosiy funksiya
def main():
    app = ApplicationBuilder().token("TELEGRAM_BOT_TOKEN").build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("balans", balans))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, add_transaction))

    print("Bot ishga tushdi!")
    app.run_polling()

if __name__ == "__main__":
    main()
