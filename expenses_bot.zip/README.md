
# Kirim va Chiqimlarni Boshqaruvchi Bot

## Foydalanish
1. Telegramda `/start` ni kiriting.
2. Kirim qo'shish: `+ 500000 Ish haqi`.
3. Chiqim qo'shish: `- 120000 Transport`.
4. Balansni ko'rish: `/balans`.

## O'rnatish
1. `pip install -r requirements.txt` yordamida kutubxonalarni o'rnating.
2. `TELEGRAM_BOT_TOKEN` ni bot.py fayliga qo'shing.
3. `python bot.py` ni ishga tushiring.
